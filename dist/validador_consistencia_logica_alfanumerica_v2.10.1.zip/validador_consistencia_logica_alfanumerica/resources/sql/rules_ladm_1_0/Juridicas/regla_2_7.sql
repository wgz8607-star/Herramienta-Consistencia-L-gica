with base as 
(
select 
lp.numero_predial
,cu.ilicode tipo_predio
,ld2.ilicode tipo_derecho
,case when cu.ilicode ='Predio.Privado' then 'Ok' else 'Fail' end as cond_2_7
from {esquema}.lc_predio lp
left join {esquema}.lc_derecho ld on ld.unidad =lp.t_id
left join {esquema}.lc_derechotipo ld2 on ld2.t_id =ld.tipo 
left join {esquema}.col_unidadadministrativabasicatipo cu on cu.t_id =lp.tipo 
where  ld2.ilicode ='Posesion'
)
select * from base 
where cond_2_7 ='Fail'